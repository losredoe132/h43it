#define F_CPU 3333333L
#define USART0_BAUD_RATE(BAUD_RATE) ((float)(F_CPU * 64 / (16 * (float)BAUD_RATE)) + 0.5)

#include <stdio.h>
#include <avr/sleep.h>
#include <avr/interrupt.h>
#include <util/delay.h>

void USART0_init(void);

static void USART0_sendChar(char c)
{
	while (!(USART0.STATUS & USART_DREIF_bm))
	{
		;                                   /* Wait for USART ready for receiving next char */
	}
	USART0.TXDATAL = c;
}

void USART0_init(void)
{

	PORTB.DIR |= PIN2_bm;                   /* Configure TX pin as an output */

	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(9600);

	USART0.CTRLB |= USART_TXEN_bm;          /* Transmitter Enable bit mask. */

}




int main(void)
{
	USART0_init();
	while (1)
	{
		    USART0_sendChar('c');
		    _delay_ms(300);

	}

}