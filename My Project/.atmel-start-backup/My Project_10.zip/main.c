
#include <stdio.h>
#include <avr/sleep.h>
#include <avr/interrupt.h>



ISR(RTC_CNT_vect)
{
	RTC.INTFLAGS = RTC_OVF_bm;            // Clear flag by writing '1':
	printf("hi");
}

void setup()
{
	RTC_init(1000);   // Start the RTC time counter, counting up to 1000 (~1 sec.)
}

void loop()
{
	// nothing to do here
}