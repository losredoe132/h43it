void TCB0_init(void)
{
	TCB0.CTRLA = TCB_CLKSEL_CLKDIV2_gc  /* CLK_PER/2 (From Prescaler) */
	| 1 << TCB_ENABLE_bp;               /* Enable: enabled */

	TCB0.CTRLB =  1 << TCB_CCMPEN_bp    /* Pin Output Enable: enabled */
	| TCB_CNTMODE_PWM8_gc;              /* 8-bit PWM */

	TCB0.CCMP = 0x28FF;                 /* 8-bit mode. Period = 255 (0xff), cmp = 40 (0x28) */
}

void TCD0_init(void)
{
	TCD0.CTRLB = 0x00;                  /* Disable Dual slope mode */
	
	TCD0.CMPASET = 2536;                /* Compare A Set: 2536 */
	TCD0.CMPACLR = 2760;                /* Compare A Clear: 2760 */
	TCD0.CMPBSET = 3277;                /* Compare B Set: 3277 */
	TCD0.CMPBCLR = 4092;                /* Compare B Clear: 4092 */

	while ((TCD0.STATUS & TCD_ENRDY_bm) == 0); /* Wait for Enable Ready to be high */

	TCD0.CTRLA = 1 << TCD_ENABLE_bp     /* Enable: enabled */
	| TCD_CNTPRES_DIV4_gc;              /* Sync clock divided by 4 */
}

void CCL_init(void)
{
	CCL.LUT1CTRLB = CCL_INSEL0_TCD0_gc  /* TCD0 WOA input source */
	| CCL_INSEL1_TCD0_gc                /* TCD0 WOB input source */;
	
	CCL.LUT1CTRLC = CCL_INSEL2_TCB0_gc  /* TCB0 WO input source */;

	CCL.TRUTH1 = 0x9F;                  /* Truth 0: 0x9F */
	
	CCL.LUT1CTRLA = 1 << CCL_ENABLE_bp  /* LUT Enable: enabled */
	| 1 << CCL_OUTEN_bp;                /* Output Enable: enabled */

	CCL.CTRLA = 1 << CCL_ENABLE_bp      /* Enable: enabled */
	| 0 << CCL_RUNSTDBY_bp;             /* Run in Standby: disabled */
}

void setup()
{
	_PROTECTED_WRITE(CLKCTRL_MCLKCTRLB, (CLKCTRL_PDIV_32X_gc | CLKCTRL_PEN_bm));  /* Slow down the main clock to 20MHz/32 = 625kHz */

	TCB0_init();
	TCD0_init();
	CCL_init();
}

void loop() {
	/* Nothing to do here */
}